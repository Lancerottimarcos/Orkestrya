# Orkestrya

Sistema de gestão para agências: dashboard, clientes, serviços, projetos, equipe, financeiro e um quadro Kanban para demandas.

## Requisitos

Este projeto usa Node.js, que foi instalado localmente (não no sistema todo) em `~/.local/node`. Para rodar comandos `npm`/`node` no terminal, adicione-o ao PATH da sessão:

```bash
export PATH="$HOME/.local/node/bin:$PATH"
```

Dica: para não precisar digitar isso toda vez, adicione essa linha ao final do seu `~/.zshrc`.

## Rodando localmente

```bash
cd caminho/para/o/projeto
npm install          # apenas na primeira vez
npx prisma migrate deploy   # aplica o banco de dados (apenas na primeira vez / após atualizações de schema)
npm run dev
```

Acesse **http://localhost:3000** no navegador.

Para rodar em modo produção (mais estável para uso contínuo):

```bash
npm run build
npm start
```

## Primeiro acesso

Um usuário administrador é criado automaticamente ao rodar o seed do banco (`npx prisma db seed`, já executado na configuração inicial):

- **Email:** admin@orquestra.local
- **Senha:** orquestra123

**Troque essa senha assim que possível** pela tela de Usuários (menu lateral → Usuários → editar seu usuário → Nova senha).

## Cadastrando outros usuários

Somente administradores podem cadastrar novos usuários: menu **Usuários** → **Novo usuário**. Defina o nível de acesso:

- **Administrador**: acesso total, incluindo Financeiro e gestão de Usuários.
- **Membro**: acesso a Clientes, Serviços, Projetos, Equipe (somente leitura) e Kanban — sem acesso a Financeiro nem a Usuários.

## Estrutura de dados

O banco é um arquivo SQLite local em `prisma/dev.db` — todos os dados ficam salvos no seu computador, sem depender de internet ou serviços externos. Para fazer backup, basta copiar esse arquivo.

## Financeiro recorrente

Todo cliente ativo com mensalidade cadastrada gera automaticamente um lançamento de entrada no mês corrente (visível em Financeiro e no Dashboard). O mesmo vale para funcionários/parceiros com pagamento mensal fixo. Essa geração acontece automaticamente sempre que o Dashboard ou o Financeiro são abertos — não é preciso rodar nada manualmente.

## Integração com Instagram e Facebook (Meta)

O Kanban tem um power-up que agenda publicações no Instagram e Facebook de verdade, via Graph API da Meta. Pra isso funcionar em produção:

### 1. Criar o app na Meta

1. Crie uma conta Business Manager em [business.facebook.com](https://business.facebook.com) e complete a **Verificação de Negócio** (Business Verification) — sem isso o App Review não é aprovado.
2. Crie um app em [developers.facebook.com/apps](https://developers.facebook.com/apps), tipo "Business".
3. Adicione o produto **Facebook Login para Empresas** e configure a **URL de redirecionamento OAuth válida**: `https://SEU_DOMINIO/api/integrations/meta/callback`.
4. Publique uma **Política de Privacidade** pública (HTTPS, mesmo domínio do app) descrevendo o que o Orkestrya acessa (posts e páginas do cliente) e como apagar os dados.
5. Peça **App Review** pra estas permissões (leva de 2 a 4 semanas, com vídeo mostrando o uso real):
   - `pages_show_list`, `pages_manage_posts`, `pages_manage_metadata`, `pages_read_engagement`
   - `instagram_basic`, `instagram_content_publish`
   - `business_management`

Enquanto o app está em modo de desenvolvimento (antes do Review), só funciona pra contas que você adicionar como testador dentro do próprio app na Meta — bom pra validar o fluxo com sua própria conta antes de liberar pros clientes.

### 2. Configurar o `.env`

```bash
META_APP_ID=...
META_APP_SECRET=...
META_REDIRECT_URI=https://SEU_DOMINIO/api/integrations/meta/callback
META_TOKEN_ENCRYPTION_KEY=...   # qualquer string longa e aleatória, usada pra criptografar os tokens salvos no banco
```

### 3. Ligar o worker de publicação

O Facebook agenda nativamente (a própria Meta publica na hora certa). O Instagram **não** tem agendamento nativo — a Content Publishing API só publica na hora em que é chamada. Por isso existe um processo separado que fica rodando e dispara a publicação do Instagram no horário exato:

```bash
pm2 start "npx tsx scripts/publish-worker.ts" --name orkestrya-publish-worker --cwd /caminho/para/o/projeto
pm2 save
```

Ele também renova sozinho os tokens de acesso perto de vencer (~60 dias de validade).

### 4. Conectar um cliente

Na página do cliente (Clientes → abrir um cliente), a seção **Integrações** tem os botões de conectar Instagram e Facebook. Só administradores veem essa seção.
